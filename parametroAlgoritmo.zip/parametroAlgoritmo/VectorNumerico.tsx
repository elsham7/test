import React from 'react'
import { RangoParametroResponse } from 'core/administracion/domain/entities/response/RangoParametroResponse'
import { DataGridForm } from 'ui/comun/formularios/DataGridForm'
import { TabContent, TabPane, Nav, NavItem, NavLink } from 'reactstrap';
import { FormularioTablas } from './FormularioTablas';


interface Props {
  rango: RangoParametroResponse | undefined
}

const VectorNumerico: React.FunctionComponent<Props> = ({ rango = null }) => {

  const [activeTab, setActiveTab] = React.useState('1')

  const onToggle = (tab: string) => {
    if (activeTab !== tab) {
      setActiveTab(tab);
    }
  }

  return (
    <React.Fragment>
      <Nav tabs>
        <NavItem>
          <NavLink
            className={activeTab === '1' ? "active" : ""}
            onClick={() => { onToggle('1'); }}
          >
            Tabla1
          </NavLink>
        </NavItem>
      </Nav>
      <TabContent activeTab={activeTab}>
        <TabPane tabId="1">
          {/* <FormularioTablas /> */}
          <br />
          <DataGridForm
            dataSource={rango?.tablas}
            keyExpr="idParamRangosAlgoritmo"
            exportEnabled={false}
            searchPanel={false}
            columns={[
              { dataField: 'idParamRangosAlgoritmo', caption: 'Id' },
              { dataField: 'descripcion', caption: 'Descripción' },
              { dataField: 'idOrden', caption: 'Orden' },
              { dataField: 'valorNumerico1', caption: 'Valor Numérico' },

              // { caption: 'Rango', width: 70, alignment: 'center', render: 'Rango', cellRender: { Rango } },

            ]}
          />
        </TabPane>
      </TabContent>
    </React.Fragment>
  )
}

export default React.memo(VectorNumerico)