const CabeceraParametroAlgoritmo = () => {
    return (
        <h3>Listado de parámetros de algoritmo</h3>
    )
}

export default CabeceraParametroAlgoritmo