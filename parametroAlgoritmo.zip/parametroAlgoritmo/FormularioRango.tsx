import React from 'react'
import { Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import { BotonForm } from 'ui/comun/formularios';
import { useRango } from 'hooks/administracion/useRango'
import VectorMatriz from './VectorMatriz';
import VectorNumerico from './VectorNumerico';
import VectorTexto from './VectorTexto';

interface Props {
    visibleModal: boolean,
    idParametro: number,
    idTipoTabla: number
    onHideModal: () => void
}

const FormularioRango: React.FunctionComponent<Props> = ({
    visibleModal = false,
    idParametro = 0,
    idTipoTabla = 0,
    onHideModal = () => null }) => {

    const { cargando, data } = useRango(idParametro, idTipoTabla);

    function Formulario() {

        if (idTipoTabla === 1)
            return <VectorMatriz rango={data} />

        if (idTipoTabla === 3)
            return <VectorNumerico rango={data} />

        if (idTipoTabla === 4)
            return <VectorTexto rango={data}/>

        return null
    }

    return (
        <Modal isOpen={visibleModal} size="lg" >
            <ModalHeader>
                <span className="text-primary">Rangos de algoritmo</span>
            </ModalHeader>
            <ModalBody>
                <Formulario />
            </ModalBody>
            <ModalFooter>
                <React.Fragment>                   
                    <BotonForm
                        text="Cancelar"
                        onClick={onHideModal} />
                </React.Fragment>
            </ModalFooter>
        </Modal>
    )
}

export default React.memo(FormularioRango)