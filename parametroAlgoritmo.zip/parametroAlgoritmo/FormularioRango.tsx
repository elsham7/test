import React from 'react'
import { Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import { BotonForm } from 'ui/comun/formularios';
import { useRango } from 'hooks/administracion/useRango'
import VectorMatriz from './VectorMatriz';
import VectorNumerico from './VectorNumerico';
import VectorTexto from './VectorTexto';

interface Props {
    visibleModal: boolean,
    idParametro: number,
    idTipoTabla: number
    onHideModal: () => void
}

const FormularioRango: React.FunctionComponent<Props> = ({
    visibleModal = false,
    idParametro = 0,
    idTipoTabla = 0,
    onHideModal = () => null }) => {

    const [refesh, setRefresh] = React.useState(Math.random());
    const { cargando, data } = useRango(idParametro, idTipoTabla,refesh);

    function Formulario() {

        if (idTipoTabla === 1)
            return <VectorMatriz rango={data} onRefreshListado={onRefreshListado}  />

        if (idTipoTabla === 3)
            return <VectorNumerico rango={data} onRefreshListado={onRefreshListado}  />

        if (idTipoTabla === 4)
            return <VectorTexto rango={data}  onRefreshListado={onRefreshListado} />

        return null
    }

    const onRefreshListado = () => {
        setRefresh(Math.random())
    }

    return (
        <Modal isOpen={visibleModal} size="lg" >
            <ModalHeader>
                <span className="text-primary">Rangos de algoritmo</span>
            </ModalHeader>
            <ModalBody>
                <Formulario />
            </ModalBody>
            <ModalFooter>
                <React.Fragment>
                    <BotonForm
                        text="Cancelar"
                        onClick={onHideModal} />
                </React.Fragment>
            </ModalFooter>
        </Modal>
    )
}

export default React.memo(FormularioRango)