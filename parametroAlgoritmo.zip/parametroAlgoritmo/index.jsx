import React from 'react'
import { useParams } from "react-router-dom";
import * as serv from '../../../core/administracion/application/services/ParametroAlgoritmoService'
import CabeceraParametroAlgoritmo from './CabeceraParametroAlgoritmo'
import MenuParametroAlgoritmo from './MenuParametroAlgoritmo'
import ListadoParametroAlgoritmo from './ListadoParametroAlgoritmo'
import FormularioRango from './FormularioRango';

const ParametroAlgoritmo = () => {
    let params = useParams();
    let idRegla = Number(params.idRegla);
    let idAlgoritmo = Number(params.idAlgoritmo);

    const opciones = [
        { id: 1, opcion: 'Editar parámetro', url: `/formulario-parametro-algoritmo/${idRegla}/${idAlgoritmo}/idParametro`, icono: 'fa-edit', visible: false },
        { id: 2, opcion: 'Listado de algoritmo', url: `/algoritmo/${idRegla}`, icono: 'fa-clipboard-list', visible: true },
        //{ id: 3, opcion: 'Rangos', url: ``, icono: 'fas fa-exchange-alt', visible: false }
    ];

    const [parametroAlgoritmo, setParametroAlgoritmo] = React.useState({
        idRegla,
        idAlgoritmo,
        idParametro: 0,
        idTipoTabla: 0,
        listado: [],
        opcionesMenu: opciones,
        opcionesMenuMapeadas: opciones,
        visibleFormularioRango: false
    });

    React.useEffect(() => {

        serv.Listado(idAlgoritmo)
            .then(response => {

                setParametroAlgoritmo({ ...parametroAlgoritmo, listado: response?.data.listado })
            })
            .catch(error => {

            });

    }, [idAlgoritmo])

    const onHideModal = () => {
        setParametroAlgoritmo({ ...parametroAlgoritmo, visibleFormularioRango: false })
    }

    return (
        <div>
            <CabeceraParametroAlgoritmo />
            <div className='row'>

                <div className='col col-3'>
                    <MenuParametroAlgoritmo parametroAlgoritmo={parametroAlgoritmo} setParametroAlgoritmo={setParametroAlgoritmo} />
                </div>

                <div className='col col-9' >
                    <ListadoParametroAlgoritmo parametroAlgoritmo={parametroAlgoritmo} setParametroAlgoritmo={setParametroAlgoritmo} />
                </div>
            </div>
            <FormularioRango
                visibleModal={parametroAlgoritmo.visibleFormularioRango}
                onHideModal={onHideModal}
                idParametro={parametroAlgoritmo.idParametro}
                idTipoTabla={parametroAlgoritmo.idTipoTabla} />
        </div>
    )
}

export default ParametroAlgoritmo