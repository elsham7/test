import React from 'react'
import { DataGridForm } from '../../comun/formularios'
import { Link } from "react-router-dom";

interface Props {
    parametroAlgoritmo: any,
    setParametroAlgoritmo: (data: any) => void
}

const ListadoParametroAlgoritmo: React.FunctionComponent<Props> = ({
    parametroAlgoritmo,
    setParametroAlgoritmo = () => null }) => {

    const onCellClick = (cell: any) => {

        const nuevasOpcionesMenu = parametroAlgoritmo.opcionesMenu.map((item: any) => {            
            return {
                ...item,
                url: item.url.replace('idParametro', cell.data.idParamAlgoritmo),
                visible: true
            }
        });

        let idTipoTabla = 0;
        switch (cell.data.tipoParametro) {
            case "3":
                idTipoTabla = 1;
                break;

            case "4":
                    idTipoTabla = 3;
                break;

            case "5":
                idTipoTabla = 4;
                break;
            default:
                break;
        }

        setParametroAlgoritmo({
            ...parametroAlgoritmo,
            opcionesMenuMapeadas: nuevasOpcionesMenu,
            idParametro: cell.data.idParamAlgoritmo,
            idTipoTabla: idTipoTabla
        })

    }

    const onCargarRangos = () => {
        setParametroAlgoritmo({ ...parametroAlgoritmo, visibleFormularioRango: true })
    }


    function Rango(item: any) {
        return item.tipoParametro >= 3 && item.tipoParametro <= 5 && <i className="fas fa-exchange-alt cursor-pointer" onClick={onCargarRangos}></i>
    }

    return (
        <>
            <div style={{ textAlign: 'right', marginBottom: 10 }}>
                <Link to={`/formulario-parametro-algoritmo/${parametroAlgoritmo.idRegla}/${parametroAlgoritmo.idAlgoritmo}/0`}><span className='btn btn-primary'><i className='fas fa-plus'></i>Añadir parámetro</span></Link>
            </div >
            <DataGridForm
                dataSource={parametroAlgoritmo.listado}
                keyExpr="idParamAlgoritmo"
                onCellClick={onCellClick}
                columns={[
                    { dataField: 'idParamAlgoritmo', caption: 'Id' },
                    { dataField: 'descripcion', caption: 'Parámetro' },
                    { dataField: 'descripcionTipo', caption: 'Tipo parámetro' },
                    { dataField: 'valorNumerico', caption: 'Valor numérico' },
                    { dataField: 'valorTexto', caption: 'Valor texto' },
                    { caption: 'Rango', width: 70, alignment: 'center', render: 'Rango', cellRender: { Rango } },
                    { dataField: 'estadoDescripcion', caption: 'Estado' },
                ]}
            />
        </>
    )
}

export default ListadoParametroAlgoritmo