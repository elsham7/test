import MenuRelacionado from '../../comun/generales/MenuRelacionado'

interface Props {
    idRegla: number,
    idAlgoritmo: number,
}

const MenuFormularioParametroAlgoritmo: React.FunctionComponent<Props> = ({ idRegla, idAlgoritmo }) => {

    const menuOpciones = [
        { id: 1, opcion: 'Listado de parametros', url: `/parametro-algoritmo/${idRegla}/${idAlgoritmo}`, icono: 'fa-clipboard-list', visible: true },
    ]

    return (
        <MenuRelacionado listado={menuOpciones} marginTop={0} height={285} />
    )
}

export default MenuFormularioParametroAlgoritmo