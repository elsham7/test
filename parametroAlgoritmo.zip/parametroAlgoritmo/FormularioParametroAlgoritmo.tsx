import React from 'react'
import { useParams, useNavigate } from "react-router-dom";
import * as serv from '../../../core/administracion/application/services/ParametroAlgoritmoService'
import { BotonForm, Etiqueta, NumberForm, SelectForm, SwitchForm, TextForm } from '../../comun/formularios';
import { ParametroAlgoritmo } from '../../../core/administracion/domain/entities/request/ParametroAlgoritmo'
import MenuFormularioParametroAlgoritmo from './MenuFormularioParametroAlgoritmo'



const FormularioParametroAlgoritmo = () => {
    let params = useParams();
    let navigate = useNavigate();

    let idRegla = Number(params.idRegla);
    let idAlgoritmo = Number(params.idAlgoritmo);
    let idParametroAlgoritmo = Number(params.idParametro);

    let parametro: ParametroAlgoritmo = {
        idParamAlgoritmo: 0,
        idAlgoritmo: 0,
        descripcion: '',
        tipoParametro: '',
        valorNumerico: 0,
        valorTexto: '',
        estado: 1
    };

    const [catalogo, setCatalogo] = React.useState([])
    const [state, setState] = React.useState(parametro)

    const tiposParametros = [
        { id: '1', text: 'Numérico' },
        { id: '2', text: 'Texto' },
        { id: '3', text: 'Vector Matriz' },
        { id: '4', text: 'Vector Numérico' },
        { id: '5', text: 'Vector Texto' }
    ];

    React.useEffect(() => {


        serv.Consultar(idParametroAlgoritmo)
            .then(response => {
            
                setCatalogo(response?.data.catalogos)

                if (idParametroAlgoritmo > 0)
                    setState(response?.data.parametro)


            })
            .catch(error => {

            });


    }, [idParametroAlgoritmo])

    const onChange = async (k: string, v: string | number | boolean) => {
        setState({ ...state, [k]: v })
    }

    const onGrabar = async (e: any) => {

        let modelState = e.validationGroup.validate();

        if (modelState.isValid) {
            if (idParametroAlgoritmo !== 0) {

                serv.Actualizar(state)
                    .then(response => {
                        navigate(`/parametro-algoritmo/${idRegla}/${idAlgoritmo}`);
                    })
                    .catch(error => {

                    });
            } else {
                serv.Anadir(state)
                    .then(response => {
                        navigate(`/parametro-algoritmo/${idRegla}/${idAlgoritmo}`);
                    })
                    .catch(error => {

                    });
            }
        }


    }

    return (
        <>

            {/* <CabeceraAlgoritmo /> */}
            <div className='row'>
                <div className='col col-3'>
                    <MenuFormularioParametroAlgoritmo idRegla={idRegla} idAlgoritmo={idAlgoritmo} />
                </div>
                <div className='col col-9'>
                    <div className='form-row'>
                        <div className='form-group col col-12'>
                            <Etiqueta etiqueta='Descripción' requerido={true} />
                            <TextForm placeholder='Ingrese la descripción'
                                value={state.descripcion}
                                maxLength={100}
                                required={true}
                                onValueChange={onChange}
                                field="descripcion"
                            />
                        </div>
                    </div>
                    <div className='form-row'>
                        <div className='form-group col col-6'>
                            <Etiqueta etiqueta='Tipo parámetro' requerido={true} />
                            <SelectForm
                                dataSource={ tiposParametros}
                                valueExpr='id'
                                displayExpr='text'
                                value={state.tipoParametro}
                                required={true}
                                onValueChange={onChange}
                                field="tipoParametro"
                            />
                        </div>

                        {
                            state.tipoParametro === '1' &&
                            <div className='form-group col col-6'>
                                <Etiqueta etiqueta='Valor numérico' requerido={true} />
                                <NumberForm placeholder='Ingrese el valor numérico'
                                    value={state.valorNumerico}
                                    min={0}
                                    max={999999}
                                    required={true}
                                    onValueChange={onChange}
                                    field="valorNumerico"
                                />
                            </div>
                        }

                        {
                            state.tipoParametro === '2' &&
                            <div className='form-group col col-6'>
                                <Etiqueta etiqueta='Valor texto' />
                                <TextForm placeholder='Ingrese el valor texto'
                                    value={state.valorTexto}
                                    maxLength={50}
                                    required={true}
                                    onValueChange={onChange}
                                    field="valorTexto"
                                />
                            </div>
                        }


                    </div>

                    <div className='form-row'>
                        <div className='form-group col col-6'>
                            <Etiqueta etiqueta='Algoritmo' />
                            <SelectForm
                                dataSource={catalogo}
                                valueExpr="codigo"
                                displayExpr='descripcion'
                                value={state.idAlgoritmo}
                                required={true}
                                onValueChange={onChange}
                                field="idAlgoritmo" />
                        </div>
                        <div className='form-group col col-6'>
                            <Etiqueta etiqueta='Estado' requerido={true} />
                            <br />
                            <SwitchForm
                                value={state.estado === 1 ? true : false}
                                onText="Activo"
                                offText="Inactivo"
                                onValue={1}
                                offValue={0}
                                onValueChange={onChange}
                                field="estado"
                                width={80}
                            />
                        </div>
                    </div>

                    <div className='form-row'>
                        <div className='form-group col col-12'>
                            <BotonForm text='Grabar' onClick={onGrabar} />
                        </div>
                    </div>


                </div>
            </div>
        </>
    )
}

export default FormularioParametroAlgoritmo