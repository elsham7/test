import MenuRelacionado from '../../comun/generales/MenuRelacionado'

interface Props {
    parametroAlgoritmo: any,
    setParametroAlgoritmo: any
}


const MenuParametroAlgoritmo : React.FunctionComponent<Props> = ({ parametroAlgoritmo, setParametroAlgoritmo }) => {
   

    return (
        <MenuRelacionado listado={parametroAlgoritmo.opcionesMenuMapeadas} marginTop={45} height={410} />
    )
}

export default MenuParametroAlgoritmo